# arithmetic operations
a = 2
b = 10

print("Addition: ", a + b)
print("Subtraction: ", a - b)
print("Multiplication: ", a * b)
print("Division: ", a / b)
print("Float division: ", a // b)
print("Modulus: ", a % b)
print("exponent: ", a ** b)


 # relational
x = a!=10
y = b==10
z = a<10 # a>b , a>=b , a<=b

print(x,y)