name = "zoha"
age = 19
height = 5.4
is_student = True 

print (name)
print (age)
print (height)
print (is_student)

name = str (input("Enter your name:"))
age = int (input ("Enter your age:"))
height = float (input("Enter your height:"))
is_student = bool (input("Enter your is_student:"))

print (name)
print (age)
print (height)
print (is_student)
